package com.company;
import java.util.Scanner;

public class Main {
    public static final Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println("Введите арифметическую операцию c двумя целыми числами от 1 до 10 включительно. \n Например: 1 + 2");
        Input input = new Input();
        Calc calc = new Calc();
        try {
        if (input.getNumType() != 0) {
               if (Calc.sign.find()) {
                   if (calc.calcArab() != 1000 || calc.calcRome() != 1000) {
                       if (input.getNumType() == 1) {
                           System.out.println("Ответ: " + calc.calcArab());
                       } else {
                           if (calc.calcArab() > 0){
                               System.out.println("Ответ: " + calc.arabicToRoman());
                           } else {
                               System.out.println("Ответ: Отсутствующий символ в римской системе счисления");
                           }
                       }
                   } else {
                       System.out.println("Операции допускаются только с числами от 1 до 10. Римские числа записываются верхним регистром");
                   }
               } else {
                   System.out.println("Вы не ввели математический символ");
               }
        } else {
            System.out.println("Калькулятор умеет работать только с арабскими или римскими цифрами одновременно");
        }
        } catch (NumberFormatException ex){
            System.out.println("Программа выполняет операции только с целыми числами от 1 до 10 и знаками + - * /  X ");
        }
    }
}
































