package com.company;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Calc {
    static Input input = new Input();
    static Matcher sign = input.sign.matcher(input.newTxt);
    Pattern pattern = Pattern.compile("\\d");
    Matcher matcherNumber = pattern.matcher(input.newTxt);

    public int calcArab() {
        int a = 0, b = 0, result = 0;
        if (matcherNumber.find()){
            a = Integer.parseInt(input.num[0]);
            b = Integer.parseInt(input.num[1]);
        }
        if (a <= 10 && a >= 1 && b <= 10 && b >= 1) {
            switch (sign.group(0)) {
                case "+" -> result = a + b;
                case "-" -> result = a - b;
                case "*" -> result = a * b;
                case "/" -> result= a / b;
            }
        } else {
            result = 1000;
        }
        return result;
    }

    public int calcRome(){
        int result = 0;
        if (input.x <= 10 && input.x >= 1 && input.y <= 10 && input.y >= 1) {
            switch (sign.group(0)) {
                case "+" -> result = input.x + input.y;
                case "-" -> result = input.x - input.y;
                case "*" -> result = input.x * input.y;
                case "/" -> result = input.x / input.y;
            }
        } else {
            result = 1000;
        }
        return result;
    }

    enum RomanNum {
        I(1), IV(4), V(5), IX(9), X(10),
        XL(40), L(50), XC(90), C(100),
        CD(400), D(500), CM(900), M(1000);

        final private int value;

        RomanNum(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }

        public static List<RomanNum> getReverseSortedValues() {
            return Arrays.stream(values())
                    .sorted(Comparator.comparing((RomanNum e) -> e.value).reversed())
                    .collect(Collectors.toList());
        }
    }

    public String arabicToRoman() {
        int number;
        number = calcRome();
        List<RomanNum> romanNumerals = RomanNum.getReverseSortedValues();
        int i = 0;
        StringBuilder sb = new StringBuilder();
        while ((number > 0) && (i < romanNumerals.size())) {
            RomanNum currentSymbol = romanNumerals.get(i);
            if (currentSymbol.getValue() <= number) {
                sb.append(currentSymbol.name());
                number -= currentSymbol.getValue();
            } else {
                i++;
            }
        }
        return sb.toString();
    }
}


