package com.company;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static com.company.Main.scanner;

public class Input {
    int a,b,c1,c2;
    int numType;
    static String txt = scanner.nextLine();
    Pattern sign = Pattern.compile("\\W");
    Pattern patternSpace = Pattern.compile("\\s");
    Matcher matcherSpace = patternSpace.matcher(txt);
    String newTxt = matcherSpace.replaceAll("");
    String[] num = newTxt.split("[+\\-*/]");
    boolean checkI = newTxt.contains("I");
    boolean checkV = newTxt.contains("V");
    boolean checkX = newTxt.contains("X");

    public int[] romanToArabic () {
        try {
            if (checkI || checkV || checkX) {
                switch (num[0]) {
                    case "I" -> {
                        a = 1;
                        c1 = 1;
                    }
                    case "II" -> {
                        a = 2;
                        c1 = 1;
                    }
                    case "III" -> {
                        a = 3;
                        c1 = 1;
                    }
                    case "IV" -> {
                        a = 4;
                        c1 = 1;
                    }
                    case "V" -> {
                        a = 5;
                        c1 = 1;
                    }
                    case "VI" -> {
                        a = 6;
                        c1 = 1;
                    }
                    case "VII" -> {
                        a = 7;
                        c1 = 1;
                    }
                    case "VIII" -> {
                        a = 8;
                        c1 = 1;
                    }
                    case "IX" -> {
                        a = 9;
                        c1 = 1;
                    }
                    case "X" -> {
                        a = 10;
                        c1 = 1;
                    }
                }
                switch (num[1]) {
                    case "I" -> {
                        b = 1;
                        c2 = 1;
                    }
                    case "II" -> {
                        b = 2;
                        c2 = 1;
                    }
                    case "III" -> {
                        b = 3;
                        c2 = 1;
                    }
                    case "IV" -> {
                        b = 4;
                        c2 = 1;
                    }
                    case "V" -> {
                        b = 5;
                        c2 = 1;
                    }
                    case "VI" -> {
                        b = 6;
                        c2 = 1;
                    }
                    case "VII" -> {
                        b = 7;
                        c2 = 1;
                    }
                    case "VIII" -> {
                        b = 8;
                        c2 = 1;
                    }
                    case "IX" -> {
                        b = 9;
                        c2 = 1;
                    }
                    case "X" -> {
                        b = 10;
                        c2 = 1;
                    }
                }
            }
        }catch  (ArrayIndexOutOfBoundsException ex){
            System.out.println("Вы не ввели математический символ");
        }
        return new int[]{a, b, c1, c2};
    }

    int x = romanToArabic()[0];
    int y = romanToArabic()[1];

    public int getNumType(){
        if (romanToArabic()[2] == romanToArabic()[3]) {
            switch (romanToArabic()[2]) {
                case 0 -> numType = 1;
                case 1 -> numType = 2;
            }
        }
        return numType;
    }
}
